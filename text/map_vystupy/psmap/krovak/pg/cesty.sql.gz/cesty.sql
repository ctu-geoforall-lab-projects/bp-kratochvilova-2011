--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: cesty; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE cesty (
    cat integer,
    rgntyp character varying(255),
    kod character varying(255),
    nazev character varying(255),
    smer character varying(255),
    poityp character varying(50),
    kod_popis character varying(50)
);


--
-- Data for Name: cesty; Type: TABLE DATA; Schema: public; Owner: martin
--

INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (1, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (2, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (3, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (4, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (5, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (6, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (7, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (8, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (9, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (10, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (11, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (12, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (13, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (14, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (15, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (16, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (17, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (18, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (19, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (20, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (21, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (22, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (23, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (24, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (25, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (26, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (27, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (28, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (29, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (30, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (31, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (32, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (33, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (34, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (35, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (36, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (37, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (38, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (39, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (40, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (41, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (42, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (43, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (44, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (45, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (46, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (47, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (48, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (49, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (50, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (51, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (52, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (53, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (54, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (55, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (56, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (57, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (58, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (59, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (60, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (61, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (62, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (63, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (64, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (65, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (66, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (67, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (68, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (69, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (70, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (71, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (72, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (73, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (74, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (75, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (76, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (77, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (78, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (79, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (80, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (81, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (82, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (83, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (84, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (85, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (86, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (87, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (88, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (89, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (90, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (91, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (92, '0x40', '0x16', 'MODRA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (93, '0x40', '0x16', 'ZELENA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (94, '0x40', '0x16', 'ZLUTA', '0', NULL, 'Stezka');
INSERT INTO cesty (cat, rgntyp, kod, nazev, smer, poityp, kod_popis) VALUES (95, '0x40', '0x16', 'CERVENA', '0', NULL, 'Stezka');


--
-- Name: cesty_1_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX cesty_1_cat ON cesty USING btree (cat);


--
-- Name: cesty_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX cesty_cat ON cesty USING btree (cat);


--
-- PostgreSQL database dump complete
--

