--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: kraje_pseudo; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE kraje_pseudo (
    cat integer,
    nk character varying(2),
    kn integer,
    kodnuts character varying(5),
    nazkr character varying(30),
    nazkr_a character varying(30),
    vymera double precision,
    ob91 integer,
    ob01 integer,
    obakt integer,
    nazcs character varying(50),
    zmenazaz character varying(8),
    zmenapol character varying(30)
);


--
-- Data for Name: kraje_pseudo; Type: TABLE DATA; Schema: public; Owner: martin
--

INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (6, 'US', 6, 'CZ042', 'Ústecký', 'Ustecky', 533492.06000000006, 824461, 820219, 820868, 'YVXFCMc', '01012000', '');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (2, 'ST', 2, 'CZ020', 'Středočeský', 'Stredocesky', 1101450.2, 1112882, 1122473, 1135795, 'VXUFEQDFVMc', '01052004', 'KODNUTS');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (4, 'PL', 4, 'CZ032', 'Plzeňský', 'Plzensky', 756121.56000000006, 558307, 550688, 550113, 'RNdFPVMc', '01012000', '');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (8, 'KH', 8, 'CZ052', 'Královéhradecký', 'Kralovehradecky', 475817.65999999997, 552809, 550724, 547563, 'MTANQZFITAEFCMc', '01012000', '');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1, 'HP', 1, 'CZ010', 'Hlavní město Praha', 'Hlavni mesto Praha', 49589.620999999999, 1214174, 1169106, 1165581, 'INAZPK OFVXQ RTAIA', '01052004', 'KODNUTS');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (9, 'PA', 9, 'CZ053', 'Pardubický', 'Pardubicky', 451850.28000000003, 508718, 508281, 505486, 'RATEYBKCMc', '01012000', '');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (10, 'VY', 10, 'CZ061', 'Vysočina', 'Vysocina', 692556.31000000006, 521068, 519211, 517511, 'ZcVQDKPA', '31052001', 'NAZKR');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (3, 'JC', 3, 'CZ031', 'Jihočeský', 'Jihocesky', 1005685.2, 622889, 625267, 625541, 'LKIQDFVMc', '31052001', 'NAZKR');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (11, 'JM', 11, 'CZ062', 'Jihomoravský', 'Jihomoravsky', 706563.81000000006, 1136832, 1127718, 1122570, 'LKIQOQTAZVMc', '31052001', 'NAZKR');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (14, 'ZL', 14, 'CZ072', 'Zlínský', 'Zlinsky', 396388.46999999997, 596903, 595010, 591866, 'dNKPVMc', '01012000', '');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (12, 'OL', 12, 'CZ071', 'Olomoucký', 'Olomoucky', 515905.28000000003, 642796, 639369, 636313, 'QNQOQYCMc', '01012000', '');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (7, 'LB', 7, 'CZ051', 'Liberecký', 'Liberecky', 316293.09000000003, 425120, 428184, 427722, 'NKBFTFCMc', '01012000', '');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (13, 'MS', 13, 'CZ080', 'Moravskoslezský', 'Moravskoslezsky', 553520.56000000006, 1283271, 1269467, 1260277, 'OQTAZVMQVNFdVMc', '01052004', 'KODNUTS');
INSERT INTO kraje_pseudo (cat, nk, kn, kodnuts, nazkr, nazkr_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (5, 'KA', 5, 'CZ041', 'Karlovarský', 'Karlovarsky', 331454.19, 301985, 304343, 304249, 'MATNQZATVMc', '01012000', '');


--
-- Name: kraje_pseudo_1_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX kraje_pseudo_1_cat ON kraje_pseudo USING btree (cat);


--
-- Name: kraje_pseudo_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX kraje_pseudo_cat ON kraje_pseudo USING btree (cat);


--
-- PostgreSQL database dump complete
--

