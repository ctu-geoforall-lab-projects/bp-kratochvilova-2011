--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: okresy_pseudo; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE okresy_pseudo (
    cat integer,
    nk character varying(2),
    kn character varying(2),
    knok character varying(4),
    kodnuts character varying(6),
    knuts character varying(4),
    kodok character varying(4),
    nazkr character varying(30),
    nazkr_a character varying(30),
    nazok character varying(30),
    nazok_a character varying(30),
    vymera double precision,
    ob91 integer,
    ob01 integer,
    obakt integer,
    nazcs character varying(50),
    zmenazaz character varying(8),
    zmenapol character varying(30)
);


--
-- Data for Name: okresy_pseudo; Type: TABLE DATA; Schema: public; Owner: martin
--

INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (603, 'US', '06', '0603', 'CZ0423', '4203', '3506', 'Ústecký', 'Ustecky', 'Litoměřice', 'Litomerice', 103212, 113883, 114259, 114953, 'NKXQOFUKCF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (601, 'US', '06', '0601', 'CZ0421', '4201', '3502', 'Ústecký', 'Ustecky', 'Děčín', 'Decin', 90899.699999999997, 133448, 133887, 133734, 'EFDKP', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (607, 'US', '06', '0607', 'CZ0427', '4207', '3510', 'Ústecký', 'Ustecky', 'Ústí nad Labem', 'Usti nad Labem', 40444.699999999997, 118325, 117780, 117594, 'YVXK PAE NABFO', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (606, 'US', '06', '0606', 'CZ0426', '4206', '3509', 'Ústecký', 'Ustecky', 'Teplice', 'Teplice', 46912.199999999997, 127872, 126098, 127103, 'XFRNKCF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (604, 'US', '06', '0604', 'CZ0424', '4204', '3507', 'Ústecký', 'Ustecky', 'Louny', 'Louny', 111776, 86640, 86020, 85897, 'NQYPc', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (207, 'ST', '02', '0207', 'CZ0207', '2107', '3207', 'Středočeský', 'Stredocesky', 'Mladá Boleslav', 'Mlada Boleslav', 105779, 111671, 114325, 114664, 'ONAEA BQNFVNAZ', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (703, 'LB', '07', '0703', 'CZ0513', '5103', '3505', 'Liberecký', 'Liberecky', 'Liberec', 'Liberec', 92469.399999999994, 159196, 159006, 158526, 'NKBFTFC', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (704, 'LB', '07', '0704', 'CZ0514', '5104', '3608', 'Liberecký', 'Liberecky', 'Semily', 'Semily', 69891.399999999994, 75547, 75355, 75041, 'VFOKNc', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (701, 'LB', '07', '0701', 'CZ0511', '5101', '3501', 'Liberecký', 'Liberecky', 'Česká Lípa', 'Ceska Lipa', 113704, 102259, 105669, 106101, 'DFVMA NKRA', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (605, 'US', '06', '0605', 'CZ0425', '4205', '3508', 'Ústecký', 'Ustecky', 'Most', 'Most', 46717.199999999997, 120212, 117196, 116731, 'OQVX', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (206, 'ST', '02', '0206', 'CZ0206', '2106', '3206', 'Středočeský', 'Stredocesky', 'Mělník', 'Melnik', 71239.399999999994, 94402, 94677, 95315, 'OFNPKM', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (802, 'KH', '08', '0802', 'CZ0522', '5202', '3604', 'Královéhradecký', 'Kralovehradecky', 'Jičín', 'Jicin', 88661.199999999997, 78650, 77761, 77066, 'LKDKP', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (203, 'ST', '02', '0203', 'CZ0203', '2103', '3203', 'Středočeský', 'Stredocesky', 'Kladno', 'Kladno', 69147.100000000006, 149407, 150198, 150536, 'MNAEPQ', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (805, 'KH', '08', '0805', 'CZ0525', '5205', '3610', 'Královéhradecký', 'Kralovehradecky', 'Trutnov', 'Trutnov', 114678, 121414, 120777, 119780, 'XTYXPQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (801, 'KH', '08', '0801', 'CZ0521', '5201', '3602', 'Královéhradecký', 'Kralovehradecky', 'Hradec Králové', 'Hradec Kralove', 87545.800000000003, 162050, 160558, 159284, 'ITAEFC MTANQZF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (210, 'ST', '02', '0210', 'CZ020A', '2110', '3210', 'Středočeský', 'Stredocesky', 'Praha-západ', 'Praha-zapad', 58614.900000000001, 74911, 83089, 88896, 'RTAIA-dARAE', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (208, 'ST', '02', '0208', 'CZ0208', '2108', '3208', 'Středočeský', 'Stredocesky', 'Nymburk', 'Nymburk', 87604, 82714, 84132, 85408, 'PcOBYTM', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (212, 'ST', '02', '0212', 'CZ020C', '2112', '3212', 'Středočeský', 'Stredocesky', 'Rakovník', 'Rakovnik', 93029.300000000003, 55152, 54084, 54271, 'TAMQZPKM', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (405, 'PL', '04', '0405', 'CZ0325', '3205', '3407', 'Plzeňský', 'Plzensky', 'Plzeň-sever', 'Plzen-sever', 131406, 72072, 72756, 73774, 'RNdFP-VFZFT', '01012003', 'VYMERA,OBAKT');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (209, 'ST', '02', '0209', 'CZ0209', '2109', '3209', 'Středočeský', 'Stredocesky', 'Praha-východ', 'Praha-vychod', 58399.5, 92510, 96061, 100265, 'RTAIA-ZcJQE', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (803, 'KH', '08', '0803', 'CZ0523', '5203', '3605', 'Královéhradecký', 'Kralovehradecky', 'Náchod', 'Nachod', 85155.199999999997, 111939, 112714, 112423, 'PAJQE', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (501, 'KA', '05', '0501', 'CZ0411', '4101', '3402', 'Karlovarský', 'Karlovarsky', 'Cheb', 'Cheb', 93273.699999999997, 86932, 88738, 89603, 'JFB', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (502, 'KA', '05', '0502', 'CZ0412', '4102', '3403', 'Karlovarský', 'Karlovarsky', 'Karlovy Vary', 'Karlovy Vary', 162821, 122430, 121998, 121212, 'MATNQZc ZATc', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (407, 'PL', '04', '0407', 'CZ0327', '3207', '3410', 'Plzeňský', 'Plzensky', 'Tachov', 'Tachov', 137870, 50036, 51439, 51573, 'XAJQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (804, 'KH', '08', '0804', 'CZ0524', '5204', '3607', 'Královéhradecký', 'Kralovehradecky', 'Rychnov nad Kněžnou', 'Rychnov nad Kneznou', 99777.100000000006, 78756, 78914, 79010, 'TcJPQZ PAE MPFePQY', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (204, 'ST', '02', '0204', 'CZ0204', '2104', '3204', 'Středočeský', 'Stredocesky', 'Kolín', 'Kolin', 84622.800000000003, 97782, 95700, 95786, 'MQNKP', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (902, 'PA', '09', '0902', 'CZ0532', '5302', '3606', 'Pardubický', 'Pardubicky', 'Pardubice', 'Pardubice', 88897.899999999994, 163121, 160987, 159910, 'RATEYBKCF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (406, 'PL', '04', '0406', 'CZ0326', '3206', '3408', 'Plzeňský', 'Plzensky', 'Rokycany', 'Rokycany', 57508.400000000001, 46118, 45788, 45576, 'TQMcCAPc', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (904, 'PA', '09', '0904', 'CZ0534', '5304', '3611', 'Pardubický', 'Pardubicky', 'Ústí nad Orlicí', 'Usti nad Orlici', 126514, 137102, 139387, 138763, 'YVXK PAE QTNKCK', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1205, 'OL', '12', '1205', 'CZ0715', '7105', '3809', 'Olomoucký', 'Olomoucky', 'Šumperk', 'Sumperk', 131556, 126190, 126567, 125794, 'WYORFTM', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1201, 'OL', '12', '1201', 'CZ0711', '7101', '3811', 'Olomoucký', 'Olomoucky', 'Jeseník', 'Jesenik', 71894.399999999994, 42583, 42413, 42148, 'LFVFPKM', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (202, 'ST', '02', '0202', 'CZ0202', '2102', '3202', 'Středočeský', 'Stredocesky', 'Beroun', 'Beroun', 66190.899999999994, 75859, 75684, 76773, 'BFTQYP', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (205, 'ST', '02', '0205', 'CZ0205', '2105', '3205', 'Středočeský', 'Stredocesky', 'Kutná Hora', 'Kutna Hora', 91685.5, 75250, 73628, 73452, 'MYXPA IQTA', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (201, 'ST', '02', '0201', 'CZ0201', '2101', '3201', 'Středočeský', 'Stredocesky', 'Benešov', 'Benesov', 152347, 94419, 93156, 93392, 'BFPFWQZ', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (901, 'PA', '09', '0901', 'CZ0531', '5301', '3603', 'Pardubický', 'Pardubicky', 'Chrudim', 'Chrudim', 102967, 106040, 105240, 104707, 'JTYEKO', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (403, 'PL', '04', '0403', 'CZ0324', '3204', '3406', 'Plzeňský', 'Plzensky', 'Plzeň-jih', 'Plzen-jih', 107594, 67794, 67700, 68536, 'RNdFP-LKI', '01012003', 'VYMERA,OBAKT');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (404, 'PL', '04', '0404', 'CZ0323', '3203', '3405', 'Plzeňský', 'Plzensky', 'Plzeň-město', 'Plzen-mesto', 13765.299999999999, 173791, 166118, 164180, 'RNdFP-OFVXQ', '01012003', 'VYMERA,OBAKT');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (211, 'ST', '02', '0211', 'CZ020B', '2111', '3211', 'Středočeský', 'Stredocesky', 'Příbram', 'Pribram', 162791, 108805, 107739, 107037, 'RUKBTAO', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1001, 'VY', '10', '1001', 'CZ0611', '6101', '3601', 'Vysočina', 'Vysocina', 'Havlíčkův Brod', 'Havlickuv Brod', 126494, 96113, 95040, 94906, 'IAZNKDMYZ BTQE', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (903, 'PA', '09', '0903', 'CZ0533', '5303', '3609', 'Pardubický', 'Pardubicky', 'Svitavy', 'Svitavy', 133471, 102455, 102667, 102106, 'VZKXAZc', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (401, 'PL', '04', '0401', 'CZ0321', '3201', '3401', 'Plzeňský', 'Plzensky', 'Domažlice', 'Domazlice', 114017, 58729, 58844, 58901, 'EQOAeNKCF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1005, 'VY', '10', '1005', 'CZ0615', '6105', '3714', 'Vysočina', 'Vysocina', 'Žďár nad Sázavou', 'Zdar nad Sazavou', 167182, 124787, 125407, 124886, 'eEAT PAE VAdAZQY', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1305, 'MS', '13', '1305', 'CZ0805', '8105', '3806', 'Moravskoslezský', 'Moravskoslezsky', 'Opava', 'Opava', 112611, 180638, 181405, 180573, 'QRAZA', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1306, 'MS', '13', '1306', 'CZ0806', '8106', '3807', 'Moravskoslezský', 'Moravskoslezsky', 'Ostrava-město', 'Ostrava-mesto', 21423.299999999999, 327371, 316744, 313088, 'QVXTAZA-OFVXQ', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (304, 'JC', '03', '0304', 'CZ0314', '3104', '3305', 'Jihočeský', 'Jihocesky', 'Písek', 'Pisek', 113813, 72074, 70550, 70347, 'RKVFM', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1202, 'OL', '12', '1202', 'CZ0712', '7102', '3805', 'Olomoucký', 'Olomoucky', 'Olomouc', 'Olomouc', 150988, 223436, 224613, 224333, 'QNQOQYC', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1003, 'VY', '10', '1003', 'CZ0613', '6103', '3304', 'Vysočina', 'Vysocina', 'Pelhřimov', 'Pelhrimov', 128990, 74614, 72984, 72531, 'RFNIUKOQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (307, 'JC', '03', '0307', 'CZ0317', '3107', '3308', 'Jihočeský', 'Jihocesky', 'Tábor', 'Tabor', 132717, 104030, 102828, 102388, 'XABQT', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1304, 'MS', '13', '1304', 'CZ0804', '8104', '3804', 'Moravskoslezský', 'Moravskoslezsky', 'Nový Jičín', 'Novy Jicin', 91775.300000000003, 158767, 159925, 159323, 'PQZc LKDKP', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (306, 'JC', '03', '0306', 'CZ0316', '3106', '3307', 'Jihočeský', 'Jihocesky', 'Strakonice', 'Strakonice', 103208, 71978, 69863, 69584, 'VXTAMQPKCF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (402, 'PL', '04', '0402', 'CZ0322', '3202', '3404', 'Plzeňský', 'Plzensky', 'Klatovy', 'Klatovy', 193960, 89767, 88043, 87573, 'MNAXQZc', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1302, 'MS', '13', '1302', 'CZ0802', '8102', '3802', 'Moravskoslezský', 'Moravskoslezsky', 'Frýdek-Místek', 'Frydek-Mistek', 127275, 227522, 226818, 226863, 'GTcEFM-OKVXFM', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1203, 'OL', '12', '1203', 'CZ0713', '7103', '3709', 'Olomoucký', 'Olomoucky', 'Prostějov', 'Prostejov', 76990.5, 112208, 109890, 109439, 'RTQVXFLQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1101, 'JM', '11', '1101', 'CZ0621', '6201', '3701', 'Jihomoravský', 'Jihomoravsky', 'Blansko', 'Blansko', 94246.600000000006, 107809, 107702, 107636, 'BNAPVMQ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1002, 'VY', '10', '1002', 'CZ0612', '6102', '3707', 'Vysočina', 'Vysocina', 'Jihlava', 'Jihlava', 118029, 108449, 108413, 108333, 'LKINAZA', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1204, 'OL', '12', '1204', 'CZ0714', '7104', '3808', 'Olomoucký', 'Olomoucky', 'Přerov', 'Prerov', 84476.199999999997, 138379, 135886, 134599, 'RUFTQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1403, 'ZL', '14', '1403', 'CZ0723', '7203', '3810', 'Zlínský', 'Zlinsky', 'Vsetín', 'Vsetin', 114308, 146898, 147064, 146127, 'ZVFXKP', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (305, 'JC', '03', '0305', 'CZ0315', '3105', '3306', 'Jihočeský', 'Jihocesky', 'Prachatice', 'Prachatice', 137503, 50985, 51369, 51477, 'RTAJAXKCF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (301, 'JC', '03', '0301', 'CZ0311', '3101', '3301', 'Jihočeský', 'Jihocesky', 'České Budějovice', 'Ceske Budejovice', 162565, 173386, 178201, 179043, 'DFVMF BYEFLQZKCF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (303, 'JC', '03', '0303', 'CZ0313', '3103', '3303', 'Jihočeský', 'Jihocesky', 'Jindřichův Hradec', 'Jindrichuv Hradec', 194376, 93048, 92887, 92761, 'LKPEUKJYZ ITAEFC', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1103, 'JM', '11', '1103', 'CZ0623', '6203', '3703', 'Jihomoravský', 'Jihomoravsky', 'Brno-venkov', 'Brno-venkov', 110816, 156189, 159169, 163253, 'BTPQ-ZFPMQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1401, 'ZL', '14', '1401', 'CZ0721', '7201', '3708', 'Zlínský', 'Zlinsky', 'Kroměříž', 'Kromeriz', 79922.100000000006, 107988, 108053, 107883, 'MTQOFUKe', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1004, 'VY', '10', '1004', 'CZ0614', '6104', '3710', 'Vysočina', 'Vysocina', 'Třebíč', 'Trebic', 151860, 117105, 117367, 116855, 'XUFBKD', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1102, 'JM', '11', '1102', 'CZ0622', '6202', '3702', 'Jihomoravský', 'Jihomoravsky', 'Brno-město', 'Brno-mesto', 23020.099999999999, 388296, 376172, 369559, 'BTPQ-OFVXQ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1106, 'JM', '11', '1106', 'CZ0626', '6206', '3712', 'Jihomoravský', 'Jihomoravsky', 'Vyškov', 'Vyskov', 88871.699999999997, 86575, 86467, 86851, 'ZcWMQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1404, 'ZL', '14', '1404', 'CZ0724', '7204', '3705', 'Zlínský', 'Zlinsky', 'Zlín', 'Zlin', 103021, 196829, 195376, 193846, 'dNKP', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1402, 'ZL', '14', '1402', 'CZ0722', '7202', '3711', 'Zlínský', 'Zlinsky', 'Uherské Hradiště', 'Uherske Hradiste', 99137.300000000003, 145188, 144517, 144010, 'YIFTVMF ITAEKWXF', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1105, 'JM', '11', '1105', 'CZ0625', '6205', '3706', 'Jihomoravský', 'Jihomoravsky', 'Hodonín', 'Hodonin', 108636, 161118, 159886, 158084, 'IQEQPKP', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1107, 'JM', '11', '1107', 'CZ0627', '6207', '3713', 'Jihomoravský', 'Jihomoravsky', 'Znojmo', 'Znojmo', 163695, 113508, 114048, 114114, 'dPQLOQ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1104, 'JM', '11', '1104', 'CZ0624', '6204', '3704', 'Jihomoravský', 'Jihomoravsky', 'Břeclav', 'Breclav', 117278, 123337, 124274, 123073, 'BUFCNAZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (302, 'JC', '03', '0302', 'CZ0312', '3102', '3302', 'Jihočeský', 'Jihocesky', 'Český Krumlov', 'Cesky Krumlov', 161503, 57388, 59569, 59941, 'DFVMc MTYONQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (602, 'US', '06', '0602', 'CZ0422', '4202', '3503', 'Ústecký', 'Ustecky', 'Chomutov', 'Chomutov', 93530.699999999997, 124081, 124979, 124856, 'JQOYXQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (702, 'LB', '07', '0702', 'CZ0512', '5102', '3504', 'Liberecký', 'Liberecky', 'Jablonec nad Nisou', 'Jablonec nad Nisou', 40228.599999999999, 88118, 88154, 88054, 'LABNQPFC PAE PKVQY', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1301, 'MS', '13', '1301', 'CZ0801', '8101', '3801', 'Moravskoslezský', 'Moravskoslezsky', 'Bruntál', 'Bruntal', 165708, 104415, 105139, 104107, 'BTYPXAN', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (1303, 'MS', '13', '1303', 'CZ0803', '8103', '3803', 'Moravskoslezský', 'Moravskoslezsky', 'Karviná', 'Karvina', 34726.900000000001, 284558, 279436, 276323, 'MATZKPA', '01052004', 'KODNUTS');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (503, 'KA', '05', '0503', 'CZ0413', '4103', '3409', 'Karlovarský', 'Karlovarsky', 'Sokolov', 'Sokolov', 75359.199999999997, 92623, 93607, 93434, 'VQMQNQZ', '', '');
INSERT INTO okresy_pseudo (cat, nk, kn, knok, kodnuts, knuts, kodok, nazkr, nazkr_a, nazok, nazok_a, vymera, ob91, ob01, obakt, nazcs, zmenazaz, zmenapol) VALUES (100, 'HP', '01', '0100', 'CZ0100', '1100', '3100', 'Hlavní město Praha', 'Hlavni mesto Praha', 'Hlavní město Praha', 'Hlavni mesto Praha', 49589.599999999999, 1214174, 1169106, 1165581, 'INAZPK OFVXQ RTAIA', '01052004', 'KODNUTS');


--
-- Name: okresy_pseudo_1_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX okresy_pseudo_1_cat ON okresy_pseudo USING btree (cat);


--
-- Name: okresy_pseudo_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX okresy_pseudo_cat ON okresy_pseudo USING btree (cat);


--
-- PostgreSQL database dump complete
--

