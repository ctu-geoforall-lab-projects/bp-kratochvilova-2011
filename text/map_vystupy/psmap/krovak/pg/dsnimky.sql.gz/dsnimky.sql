--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = true;

--
-- Name: dsnimky; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE dsnimky (
    cat integer,
    id character varying(7),
    datum character varying(10),
    skener character varying(5),
    nosic character varying(15),
    georef character varying(15),
    format character varying(10),
    uzemi character varying(50),
    ul_y real,
    ul_x real,
    ll_y real,
    ll_x real,
    ur_y real,
    ur_x real,
    lr_y real,
    lr_x real,
    ce_y real,
    ce_x real,
    zona integer,
    url character varying(100)
);


--
-- Data for Name: dsnimky; Type: TABLE DATA; Schema: public; Owner: martin
--

INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (12848, '012-848', '1992-8-29 ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland,Slovakia                    ', -472880, -942674, -483807, -1165550, -228854, -954663, -240039, -1177710, -356399, -1060140, 34, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=12848');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (12849, '012-849', '1986-10-16', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Hungary,Poland,Slovakia            ', -523280, -1095620, -534292, -1316240, -290809, -1107140, -301852, -1327930, -412561, -1211730, 34, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=12849');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (12882, '012-882', '1991-7-6  ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', -832889, -738394, -861468, -960108, -590286, -769647, -619094, -991529, -725939, -864914, 33, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=12882');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (12883, '012-883', '1991-7-6  ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=12883');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (12884, '012-884', '1991-8-7  ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Germany                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=12884');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (12898, '012-898', '1990-8-3  ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany                            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=12898');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (17751, '017-751', '1992-7-9  ', 'TM   ', 'USGS           ', 'L1G            ', 'BSQ       ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=17751');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (17752, '017-752', '1984-7-11 ', 'TM   ', 'USGS           ', 'L1G            ', 'BSQ       ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=17752');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (18375, '018-375', '1987-8-23 ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Poland,Slovakia            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=18375');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (18385, '018-385', '1991-9-10 ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland                             ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=18385');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (18386, '018-386', '1991-9-10 ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Hungary,Slovakia           ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=18386');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (18397, '018-397', '1990-8-29 ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=18397');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (18398, '018-398', '1990-8-29 ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=18398');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (18399, '018-399', '1991-9-1  ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Germany                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=18399');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (18408, '018-408', '1990-8-3  ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany                            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=18408');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21139, '021-139', '1979-10-10', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland,Slovakia                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21139');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21158, '021-158', '1979-5-30 ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland                             ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21158');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21159, '021-159', '1979-5-30 ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic                            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21159');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21168, '021-168', '1979-5-31 ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21168');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21169, '021-169', '1979-5-31 ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland                             ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21169');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21170, '021-170', '1979-5-22 ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Germany                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21170');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21181, '021-181', '1975-4-29 ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany                            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21181');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21182, '021-182', '1976-5-2  ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Germany                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21182');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (21193, '021-193', '1973-5-28 ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany                            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=21193');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (31260, '031-260', '1976-4-2  ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Hungary,Slovakia           ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=31260');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (31281, '031-281', '1976-5-11 ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=31281');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (33069, '033-069', '1990-8-31 ', 'TM   ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland,Slovakia                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=33069');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36124, '036-124', '1999-9-13 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany                            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36124');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36125, '036-125', '1999-9-13 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany                            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36125');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36296, '036-296', '2000-8-2  ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland,Slovakia                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36296');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36297, '036-297', '2000-8-2  ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Poland,Slovakia            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36297');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36343, '036-343', '2001-5-24 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland                             ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36343');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36344, '036-344', '2001-5-24 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Hungary,Slovakia           ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36344');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36381, '036-381', '2000-6-13 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36381');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36382, '036-382', '1999-9-15 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36382');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36383, '036-383', '1999-9-15 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Germany                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36383');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36424, '036-424', '2000-6-20 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36424');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36425, '036-425', '2000-6-20 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Germany,Poland                     ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36425');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36426, '036-426', '2001-8-26 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Austria,Czech Republic,Germany                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36426');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36564, '036-564', '2000-5-7  ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland,Slovakia                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36564');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (36565, '036-565', '2001-5-26 ', 'ETM+ ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Hungary,Poland,Slovakia            ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=36565');
INSERT INTO dsnimky (cat, id, datum, skener, nosic, georef, format, uzemi, ul_y, ul_x, ll_y, ll_x, ur_y, ur_x, lr_y, lr_x, ce_y, ce_x, zona, url) VALUES (44131, '044-131', '1976-5-8  ', 'MSS  ', 'EarthSat       ', 'Ortho,GeoCover ', 'GeoTIFF   ', 'Czech Republic,Poland,Slovakia                    ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://glcfapp.umiacs.umd.edu:8080/esdi/ftp?id=44131');


--
-- Name: dsnimky_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX dsnimky_cat ON dsnimky USING btree (cat);


--
-- PostgreSQL database dump complete
--

