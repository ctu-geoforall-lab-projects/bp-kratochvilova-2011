--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = true;

--
-- Name: cr; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE cr (
    cat integer,
    nazev character varying(50),
    nazev_a character varying(50)
);


--
-- Data for Name: cr; Type: TABLE DATA; Schema: public; Owner: martin
--

INSERT INTO cr (cat, nazev, nazev_a) VALUES (1, 'Česká republika', 'Ceska republika');


--
-- Name: cr_1_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX cr_1_cat ON cr USING btree (cat);


--
-- Name: cr_cat; Type: INDEX; Schema: public; Owner: martin; Tablespace: 
--

CREATE UNIQUE INDEX cr_cat ON cr USING btree (cat);


--
-- PostgreSQL database dump complete
--

